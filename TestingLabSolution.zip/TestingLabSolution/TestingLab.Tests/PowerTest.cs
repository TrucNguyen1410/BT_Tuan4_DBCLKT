﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestingLab;

[TestClass]
public class PowerTest
{
    [TestMethod]
    public void Power_N_Zero()
    {
        Assert.AreEqual(1.0, MathUtil.Power(5, 0));
    }

    [TestMethod]
    public void Power_Positive()
    {
        Assert.AreEqual(8.0, MathUtil.Power(2, 3));
    }

    [TestMethod]
    public void Power_Negative()
    {
        Assert.AreEqual(0.25, MathUtil.Power(2, -2));
    }
}
