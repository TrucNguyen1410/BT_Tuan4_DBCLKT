﻿using System;
using System.Collections.Generic;

namespace TestingLab
{
    public class Radix
    {
        private int number;

        public Radix(int number)
        {
            if (number < 0)
                throw new ArgumentException("Incorrect Value");
            this.number = number;
        }

        public string ConvertDecimalToAnother(int radix)
        {
            if (radix < 2 || radix > 16)
                throw new ArgumentException("Invalid Radix");

            int n = number;
            List<string> result = new List<string>();

            while (n > 0)
            {
                int value = n % radix;
                result.Add(value < 10
                    ? value.ToString()
                    : ((char)('A' + value - 10)).ToString());
                n /= radix;
            }

            result.Reverse();
            return string.Join("", result);
        }
    }
}
