﻿namespace TestingLab
{
    public class HocVien
    {
        public double Mon1 { get; set; }
        public double Mon2 { get; set; }
        public double Mon3 { get; set; }

        public double DiemTB()
        {
            return (Mon1 + Mon2 + Mon3) / 3;
        }

        public bool DuocHocBong()
        {
            return DiemTB() >= 8.0 &&
                   Mon1 >= 5 &&
                   Mon2 >= 5 &&
                   Mon3 >= 5;
        }
    }
}
