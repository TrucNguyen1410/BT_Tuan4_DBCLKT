﻿using TestingLab;

[TestClass]
public class RectangleTest
{
    [TestMethod]
    public void Area_Test()
    {
        HinhChuNhat h = new HinhChuNhat(new Diem(0, 10), new Diem(10, 0));
        Assert.AreEqual(100, h.DienTich());
    }

    [TestMethod]
    public void Intersect_Test()
    {
        HinhChuNhat h1 = new HinhChuNhat(new Diem(0, 10), new Diem(10, 0));
        HinhChuNhat h2 = new HinhChuNhat(new Diem(5, 5), new Diem(15, -5));
        Assert.IsTrue(h1.GiaoNhau(h2));
    }
}
