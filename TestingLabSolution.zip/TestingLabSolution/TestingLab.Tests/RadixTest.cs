﻿using TestingLab;

[TestClass]
public class RadixTest
{
    [TestMethod]
    public void Convert_Binary()
    {
        Radix r = new Radix(10);
        Assert.AreEqual("1010", r.ConvertDecimalToAnother(2));
    }

    [TestMethod]
    [ExpectedException(typeof(System.ArgumentException))]
    public void Invalid_Radix()
    {
        new Radix(10).ConvertDecimalToAnother(20);
    }
}
