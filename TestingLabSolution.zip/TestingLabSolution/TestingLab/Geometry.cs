﻿using System;

namespace TestingLab
{
    public class Diem
    {
        public int X { get; set; }
        public int Y { get; set; }

        public Diem(int x, int y)
        {
            X = x;
            Y = y;
        }
    }

    public class HinhChuNhat
    {
        private Diem tl;
        private Diem br;

        public HinhChuNhat(Diem tl, Diem br)
        {
            this.tl = tl;
            this.br = br;
        }

        public int DienTich()
        {
            return Math.Abs((br.X - tl.X) * (tl.Y - br.Y));
        }

        public bool GiaoNhau(HinhChuNhat h)
        {
            return !(h.br.X < tl.X ||
                     h.tl.X > br.X ||
                     h.tl.Y < br.Y ||
                     h.br.Y > tl.Y);
        }
    }
}
