﻿using TestingLab;

[TestClass]
public class HocVienTest
{
    [TestMethod]
    public void HocBong_Dat()
    {
        HocVien hv = new HocVien { Mon1 = 8, Mon2 = 9, Mon3 = 8 };
        Assert.IsTrue(hv.DuocHocBong());
    }

    [TestMethod]
    public void HocBong_KhongDat()
    {
        HocVien hv = new HocVien { Mon1 = 9, Mon2 = 4, Mon3 = 9 };
        Assert.IsFalse(hv.DuocHocBong());
    }
}
