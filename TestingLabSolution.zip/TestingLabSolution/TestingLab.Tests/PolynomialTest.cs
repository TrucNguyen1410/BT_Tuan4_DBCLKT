﻿using TestingLab;

[TestClass]
public class PolynomialTest
{
    [TestMethod]
    public void Polynomial_Correct()
    {
        Polynomial p = new Polynomial(2, new System.Collections.Generic.List<int> { 1, 2, 3 });
        Assert.AreEqual(17, p.Cal(2));
    }

    [TestMethod]
    [ExpectedException(typeof(System.ArgumentException))]
    public void Polynomial_Invalid()
    {
        new Polynomial(2, new System.Collections.Generic.List<int> { 1, 2 });
    }
}
